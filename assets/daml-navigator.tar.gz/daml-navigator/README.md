# Navigator packed by Digital Asset

## Table of contents

- [Introduction](#introduction)
- [Prerequisites](#-prerequisites-)
- [TL;DR](#tldr)
- [Configuration and installation details](#configuration-and-installation-details)
- [Limitations](#limitations)
- [Parameters](#parameters)
- [License](#license)

---
## Introduction

Navigator deployment

---
## 🚦 Prerequisites 🚦

- Kubernetes `1.24+`
- Helm `3.9+`
- Ledger API (exposed by a Canton Participant connected to a Domain)
- Cert-manager + CSI driver (only if TLS is required by the Ledger API)

---
## TL;DR

```console
helm repo add digitalasset https://digital-asset.github.io/daml-helm-charts/
helm install mynavigator digitalasset/daml-navigator
```

#### Minimum viable configuration

Example configuration connecting to `participant1` in namespace `canton` within the same Kubernetes cluster.

⚠️ _TLS and JWT authentication are disabled_

```yaml
ledgerAPI:
  host: "participant1-canton-participant.canton.svc.cluster.local"
```

---
## Configuration and installation details

### TLS

To enable TLS (and mTLS) everywhere, it is mandatory to have [Cert-manager](https://cert-manager.io/docs/) and its CSI driver
already deployed in a specific namespace of your Kubernetes cluster. A certificate issuer must be ready to use (you can use
external issuer types), you may customize all the Cert-manager CSI driver related values:

```yaml
certManager:
  issuerGroup: "cert-manager.io"
  issuerKind: "Issuer"
  issuerName: "my-cert-manager-issuer"
```

### Limitations

⚠️ **Upgrading to a different release is not supported for now** ⚠️

---
## Parameters

### Common parameters

| Name                | Description                                                                                    | Value                    |
| ------------------- | ---------------------------------------------------------------------------------------------- | ------------------------ |
| `nameOverride`      | String to partially override `common.name` template (will maintain the release name)           | `""`                     |
| `fullnameOverride`  | String to fully override `common.fullname` template                                            | `""`                     |
| `replicaCount`      | Number of Navigator pods to deploy                                                             | `1`                      |
| `image.registry`    | Docker image registry                                                                          | `docker.io/digitalasset` |
| `image.repository`  | Docker image repository                                                                        | `daml-sdk`               |
| `image.tag`         | Docker image tag (immutable tags are recommended)                                              | `""`                     |
| `image.digest`      | Docker image digest in the way `sha256:aa...`. If this parameter is set, overrides `image.tag` | `""`                     |
| `image.pullPolicy`  | Docker image pull policy. Allowed values: `Always`, `Never`, `IfNotPresent`                    | `IfNotPresent`           |
| `image.pullSecrets` | Specify Docker registry secret names as an array                                               | `[]`                     |
| `commonLabels`      | Add labels to all the deployed resources                                                       | `{}`                     |

### Navigator configuration

| Name                              | Description                                                                                                                                   | Value         |
| --------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- | ------------- |
| `ledgerAPI.host`                  | Ledger API hostname                                                                                                                           | `participant` |
| `ledgerAPI.port`                  | Ledger API port                                                                                                                               | `4001`        |
| `ledgerAPI.inboundMessageSizeMax` | Maximum message size in bytes from the Ledger API                                                                                             | `52428800`    |
| `assets`                          | Folder where frontend assets are available                                                                                                    | `""`          |
| `accessTokenFile`                 | Path to access token. Required if JWT authentication is enabled on the Ledger API                                                             | `""`          |
| `configFile`                      | Path to configuration file                                                                                                                    | `""`          |
| `time`                            | Time provider. Allowed values: `auto`, `static`, `simulated`, `wallclock`                                                                     | `auto`        |
| `featureUserManagement`           | By default the login screen is populated by querying the user management service. Disable to query party management instead (pre-2.0 default) | `false`       |

### TLS configuration

| Name                           | Description                                                                                                                     | Value                         |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------- | ----------------------------- |
| `tls.enabled`                  | Enable TLS to Ledger API (gRPC)                                                                                                 | `false`                       |
| `tls.certManager`              | Cert-manager CSI driver configuration (only used when TLS is enabled), will automatically mount certificates in folder `/tls`   |                               |
| `tls.certManager.issuerGroup`  | Cert-Manager issuer group. Allowed values: `cert-manager.io`, `cas-issuer.jetstack.io`, `cert-manager.k8s.cloudflare.com`, etc. | `cert-manager.io`             |
| `tls.certManager.issuerKind`   | Cert-Manager issuer kind. Allowed values: `Issuer`, `ClusterIssuer`, `GoogleCASIssuer`, `OriginIssuer`, etc.                    | `Issuer`                      |
| `tls.certManager.issuerName`   | Cert-manager issuer name                                                                                                        | `my-cert-manager-issuer-tls`  |
| `tls.certManager.fsGroup`      | Cert-manager FS Group of mounted files, should be paired with and match container `runAsGroup`                                  | `102`                         |
| `tls.ca`                       | CA certificate, if empty `""` JVM default trust store is used                                                                   | `/tls/ca.crt`                 |
| `mtls.enabled`                 | Enable mTLS to Ledger API (gRPC)                                                                                                | `false`                       |
| `mtls.certManager`             | Cert-manager CSI driver configuration (only used when TLS is enabled), will automatically mount certificates in folder `/mtls`  |                               |
| `mtls.certManager.issuerGroup` | Cert-Manager issuer group. Allowed values: `cert-manager.io`, `cas-issuer.jetstack.io`, `cert-manager.k8s.cloudflare.com`, etc. | `cert-manager.io`             |
| `mtls.certManager.issuerKind`  | Cert-Manager issuer kind. Allowed values: `Issuer`, `ClusterIssuer`, `GoogleCASIssuer`, `OriginIssuer`, etc.                    | `Issuer`                      |
| `mtls.certManager.issuerName`  | Cert-manager issuer name                                                                                                        | `my-cert-manager-issuer-mtls` |
| `mtls.certManager.fsGroup`     | Cert-manager FS Group of mounted files, should be paired with and match container `runAsGroup`                                  | `102`                         |
| `mtls.chain`                   | Certificate chain                                                                                                               | `/mtls/tls.crt`               |
| `mtls.key`                     | Certificate private key (PKCS-8)                                                                                                | `/mtls/tls.key`               |

### Container ports

| Name   | Description               | Value  |
| ------ | ------------------------- | ------ |
| `port` | Server listen port (HTTP) | `8080` |

### Deployment configuration

| Name                     | Description                                                           | Value |
| ------------------------ | --------------------------------------------------------------------- | ----- |
| `environment`            | Container environment variables                                       | `{}`  |
| `environmentSecrets`     | Container secret environment variables                                | `{}`  |
| `deployment.annotations` | Deployment extra annotations                                          | `{}`  |
| `deployment.labels`      | Deployment extra labels                                               | `{}`  |
| `deployment.strategy`    | Deployment strategy                                                   | `{}`  |
| `pod.annotations`        | Extra annotations for Deployment pods                                 | `{}`  |
| `pod.labels`             | Extra labels for Deployment pods                                      | `{}`  |
| `affinity`               | Affinity for pods assignment                                          | `{}`  |
| `nodeSelector`           | Node labels for pods assignment                                       | `{}`  |
| `resources`              | Resources requests/limits for Navigator container                     | `{}`  |
| `tolerations`            | Tolerations for pods assignment                                       | `[]`  |
| `extraVolumeMounts`      | Specify extra list of additional volumeMounts for Navigator container | `[]`  |
| `extraVolumes`           | Specify extra list of additional volumes for Navigator pod            | `[]`  |

### Service configuration

| Name                  | Description                                                                          | Value       |
| --------------------- | ------------------------------------------------------------------------------------ | ----------- |
| `service.type`        | Service type. Allowed values: `ExternalName`, `ClusterIP`, `NodePort`, `LoadBalance` | `ClusterIP` |
| `service.annotations` | Service extra annotations                                                            | `{}`        |
| `service.labels`      | Service extra labels                                                                 | `{}`        |
| `service.port`        | Web UI port (HTTP)                                                                   | `8080`      |

---
## License

Copyright &copy; 2023 Digital Asset (Switzerland) GmbH and/or its affiliates

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
